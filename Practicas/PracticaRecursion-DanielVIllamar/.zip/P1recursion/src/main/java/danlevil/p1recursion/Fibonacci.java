/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package danlevil.p1recursion;

/**
 *
 * @author CltControl
 */
public class Fibonacci {

    
    public static int fibunacci(int n)
    {
    if(n == 1)
        return 0;
    if(n == 2)
        return 1;
    else
        return fibunacci(n-1) + fibunacci(n-2);
    }
    
    public static void esPalindromo(String t){
//    String[] arreglo = t.split("");
//    if((arreglo[arreglo.length]).equals(arreglo[0]))
    }
    public static void revertir(Object[] t){
        
    }
}
