/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package danlevil.p1recursion;

import static danlevil.p1recursion.Fibonacci.fibunacci;

/**
 *
 * @author CltControl
 */
public class P1recursion {

    public static void main(String[] args) {
        System.out.println("Factorial\n");
        System.out.println("Factorial de 6 :"+ Factorial.factorial(6));
        System.out.println("FIBONACCI");
        System.out.println(Fibonacci.fibunacci(9));
    }
}
